﻿using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Threading.Tasks;
using ClubApp.Data;
using ClubApp.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace ClubApp.Pages
{
    [Authorize]
    public class EditModel : PageModel
    {
        private readonly AppDbContext _db;
        private readonly IPasswordHasher<User> _hasher;

        public EditModel(AppDbContext db, IPasswordHasher<User> hasher)
        {
            _db = db; _hasher = hasher;
        }

        [BindProperty] public EditInput Input { get; set; } = new EditInput();

        public class EditInput
        {
            public int Id { get; set; }

            [Required, StringLength(32, MinimumLength = 3)]
            public string UserName { get; set; } = string.Empty;

            [Required, EmailAddress]
            public string Email { get; set; } = string.Empty;

            [StringLength(100, MinimumLength = 6)]
            public string? NewPassword { get; set; }
        }

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (!TryGetCurrentUserId(out var currentId) || currentId != id)
                return Forbid();

            var user = await _db.Users.FindAsync(id);
            if (user == null) return NotFound();

            Input = new EditInput { Id = user.Id, UserName = user.UserName, Email = user.Email };
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!TryGetCurrentUserId(out var currentId) || currentId != Input.Id)
                return Forbid();

            if (!ModelState.IsValid) return Page();

            var user = await _db.Users.FirstOrDefaultAsync(u => u.Id == Input.Id);
            if (user == null) return NotFound();

            if (!string.Equals(user.UserName, Input.UserName))
            {
                var exists = await _db.Users.AnyAsync(u => u.UserName == Input.UserName && u.Id != user.Id);
                if (exists)
                {
                    ModelState.AddModelError(nameof(Input.UserName), "Username already taken.");
                    return Page();
                }
            }

            user.UserName = Input.UserName.Trim();
            user.Email = Input.Email.Trim();

            if (!string.IsNullOrWhiteSpace(Input.NewPassword))
                user.PasswordHash = _hasher.HashPassword(user, Input.NewPassword);

            await _db.SaveChangesAsync();

            // refresh cookie if username changed
            if (!string.Equals(User.Identity?.Name, user.UserName, System.StringComparison.Ordinal))
            {
                await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);

                var claims = new[]
                {
                    new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                    new Claim(ClaimTypes.Name, user.UserName)
                };
                var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
                await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));
            }

            return RedirectToPage("/Club");
        }

        // NEW: delete handler (called by the second form)
        public async Task<IActionResult> OnPostDeleteAsync()
        {
            // Only allow deleting your own account
            if (!TryGetCurrentUserId(out var currentId) || currentId != Input.Id)
                return Forbid();

            var user = await _db.Users.FindAsync(Input.Id);
            if (user == null) return NotFound();

            _db.Users.Remove(user);
            await _db.SaveChangesAsync();

            // End session and return to Login
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            TempData["Message"] = "Your account has been deleted.";
            return RedirectToPage("/Login");
        }

        private bool TryGetCurrentUserId(out int id)
        {
            id = 0;
            var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return int.TryParse(value, out id);
        }
    }
}
