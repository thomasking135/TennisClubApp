﻿using System;                                   // for Console.WriteLine
using ClubApp.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure; // for Database.GetDbConnection()


namespace ClubApp.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
            try
            {
                var path = Database.GetDbConnection()?.DataSource ?? "(no connection)";
                Console.WriteLine($"[EF CORE] Using database: {path}");
            }
            catch
            {
                // Ignore if context is created design-time without a provider
            }
        }


        public DbSet<User> Users { get; set; } = null!;   // EF sets this at runtime


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<User>()
                .HasIndex(u => u.UserName)
                .IsUnique();
        }
    }
}
