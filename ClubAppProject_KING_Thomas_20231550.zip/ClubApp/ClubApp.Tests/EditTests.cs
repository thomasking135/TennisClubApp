﻿using System.Threading.Tasks;
using ClubApp.Data;
using ClubApp.Models;
using ClubApp.Pages;
using Microsoft.AspNetCore.Identity;
using Xunit;

namespace ClubApp.Tests
{
    public class EditTests
    {
        [Fact]
        public async Task Edit_OnGet_ForDifferentUserId_ReturnsForbid()
        {
            using var db = TestHelpers.CreateInMemoryDb(nameof(Edit_OnGet_ForDifferentUserId_ReturnsForbid));
            var hasher = new PasswordHasher<User>();

            var me = new User { UserName = "me", Email = "me@x.com", PasswordHash = "x" };
            var other = new User { UserName = "them", Email = "them@x.com", PasswordHash = "y" };
            db.Users.AddRange(me, other);
            await db.SaveChangesAsync();

            var page = new EditModel(db, hasher);
            TestHelpers.AttachPageContext(page, me.Id, me.UserName);

            var result = await page.OnGetAsync(other.Id);

            Assert.IsType<Microsoft.AspNetCore.Mvc.ForbidResult>(result);
        }
    }
}
