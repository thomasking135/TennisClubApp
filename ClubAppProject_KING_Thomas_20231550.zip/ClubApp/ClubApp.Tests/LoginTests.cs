﻿using System.Threading.Tasks;
using ClubApp.Data;
using ClubApp.Models;
using ClubApp.Pages;
using Microsoft.AspNetCore.Identity;
using Xunit;

namespace ClubApp.Tests
{
    public class LoginTests
    {
        [Fact]
        public async Task Login_WithWrongPassword_ReturnsPageWithModelError()
        {
            using var db = TestHelpers.CreateInMemoryDb(nameof(Login_WithWrongPassword_ReturnsPageWithModelError));
            var hasher = new PasswordHasher<User>();

            var u = new User { UserName = "alice", Email = "a@x.com" };
            u.PasswordHash = hasher.HashPassword(u, "Correct$123");
            db.Users.Add(u);
            await db.SaveChangesAsync();

            var page = new LoginModel(db, hasher)
            {
                Input = new LoginModel.LoginInput { UserName = "alice", Password = "WRONG" }
            };

            var result = await page.OnPostAsync();

            Assert.IsType<Microsoft.AspNetCore.Mvc.RazorPages.PageResult>(result);
            Assert.False(page.ModelState.IsValid);
            Assert.True(page.ModelState.ErrorCount > 0);
        }
    }
}
