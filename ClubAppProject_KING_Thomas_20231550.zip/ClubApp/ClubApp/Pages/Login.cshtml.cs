﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Security.Claims;
using System.Threading.Tasks;
using ClubApp.Data;
using ClubApp.Models;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace ClubApp.Pages
{
    public class LoginModel : PageModel
    {
        private readonly AppDbContext _db;
        private readonly IPasswordHasher<User> _hasher;

        public LoginModel(AppDbContext db, IPasswordHasher<User> hasher)
        {
            _db = db; _hasher = hasher;
        }

        [BindProperty] public LoginInput Input { get; set; } = new LoginInput();

        public class LoginInput
        {
            [Required] public string UserName { get; set; } = string.Empty;
            [Required] public string Password { get; set; } = string.Empty;
        }

        public void OnGet() { }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid) return Page();

            var user = await _db.Users.FirstOrDefaultAsync(u => u.UserName == Input.UserName);
            if (user == null)
            {
                ModelState.AddModelError(string.Empty, "Invalid login.");
                return Page();
            }

            var verify = _hasher.VerifyHashedPassword(user, user.PasswordHash, Input.Password);
            if (verify == PasswordVerificationResult.Failed)
            {
                ModelState.AddModelError(string.Empty, "Invalid login.");
                return Page();
            }

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new Claim(ClaimTypes.Name, user.UserName)
            };
            var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(identity));

            return RedirectToPage("/Club");
        }
    }
}
