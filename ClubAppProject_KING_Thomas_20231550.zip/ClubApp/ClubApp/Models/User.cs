﻿using System.ComponentModel.DataAnnotations;

namespace ClubApp.Models
{
    public enum SlotOption
    {
        None = 0,
        SaturdayMorning = 1,   // 10am–12pm
        SaturdayAfternoon = 2  // 2pm–4pm
    }

    public class User
    {
        public int Id { get; set; }

        [Required, StringLength(32)]
        public string UserName { get; set; } = string.Empty;

        [Required, EmailAddress, StringLength(256)]
        public string Email { get; set; } = string.Empty;

        [Required]
        public string PasswordHash { get; set; } = string.Empty;

        // NEW: the user’s chosen slot (nullable; null/None = not assigned)
        public SlotOption? Slot { get; set; } = SlotOption.None;
    }
}
