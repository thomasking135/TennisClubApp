﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using ClubApp.Data;
using ClubApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace ClubApp.Pages
{
    [Authorize]
    public class ClubModel : PageModel
    {
        private readonly AppDbContext _db;
        public ClubModel(AppDbContext db) { _db = db; }

        public List<User> Users { get; set; } = new List<User>();
        public int CurrentUserId { get; set; }

        public async Task OnGetAsync()
        {
            Users = await _db.Users
                .AsNoTracking()
                .OrderBy(u => u.UserName)
                .ToListAsync();

            if (int.TryParse(User.FindFirstValue(ClaimTypes.NameIdentifier), out var id))
                CurrentUserId = id;
        }
    }
}
