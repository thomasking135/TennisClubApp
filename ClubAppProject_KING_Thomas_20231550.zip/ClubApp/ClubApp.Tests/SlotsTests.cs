﻿using System.Threading.Tasks;
using ClubApp.Data;
using ClubApp.Models;
using ClubApp.Pages;
using Xunit;

namespace ClubApp.Tests
{
    public class SlotsTests
    {
        [Fact]
        public async Task Slots_SelectMorning_WhenAlready3Members_ShowsError_AndDoesNotAssign()
        {
            using var db = TestHelpers.CreateInMemoryDb(nameof(Slots_SelectMorning_WhenAlready3Members_ShowsError_AndDoesNotAssign));

            db.Users.Add(new User { UserName = "a", Email = "a@x.com", PasswordHash = "x", Slot = SlotOption.SaturdayMorning });
            db.Users.Add(new User { UserName = "b", Email = "b@x.com", PasswordHash = "x", Slot = SlotOption.SaturdayMorning });
            db.Users.Add(new User { UserName = "c", Email = "c@x.com", PasswordHash = "x", Slot = SlotOption.SaturdayMorning });
            var me = new User { UserName = "me", Email = "me@x.com", PasswordHash = "x", Slot = SlotOption.None };
            db.Users.Add(me);
            await db.SaveChangesAsync();

            var page = new SlotsModel(db) { SelectMorning = true, SelectAfternoon = false };
            TestHelpers.AttachPageContext(page, me.Id, me.UserName);

            var result = await page.OnPostAsync();

            Assert.IsType<Microsoft.AspNetCore.Mvc.RazorPages.PageResult>(result);
            Assert.False(page.ModelState.IsValid);

            var meReloaded = await db.Users.FindAsync(me.Id);
            Assert.Equal(SlotOption.None, meReloaded!.Slot);
        }
    }
}
