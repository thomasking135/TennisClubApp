﻿using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using ClubApp.Data;
using ClubApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;

namespace ClubApp.Pages
{
    [Authorize]
    public class SlotsModel : PageModel
    {
        private readonly AppDbContext _db;
        public SlotsModel(AppDbContext db) { _db = db; }

        // Display
        public List<User> MorningMembers { get; set; } = new List<User>();
        public List<User> AfternoonMembers { get; set; } = new List<User>();
        public int MorningCount => MorningMembers.Count;
        public int AfternoonCount => AfternoonMembers.Count;

        // Form binding
        [BindProperty] public bool SelectMorning { get; set; }
        [BindProperty] public bool SelectAfternoon { get; set; }

        // Alerts
        public string Message { get; set; }
        public string SuccessClass { get; set; } = "alert-success";

        public async Task<IActionResult> OnGetAsync()
        {
            await LoadListsAsync();

            // Pre-check the current user’s selection
            if (TryGetCurrentUserId(out var id))
            {
                var me = await _db.Users.AsNoTracking().FirstOrDefaultAsync(u => u.Id == id);
                if (me?.Slot == SlotOption.SaturdayMorning) SelectMorning = true;
                if (me?.Slot == SlotOption.SaturdayAfternoon) SelectAfternoon = true;
            }

            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            await LoadListsAsync();

            if (!TryGetCurrentUserId(out var id)) return Forbid();

            // Enforce only one box at a time
            if (SelectMorning && SelectAfternoon)
            {
                ModelState.AddModelError(string.Empty, "Please choose only one slot.");
                return Page();
            }

            var me = await _db.Users.FirstOrDefaultAsync(u => u.Id == id);
            if (me == null) return NotFound();

            // Determine requested slot (or None to unassign)
            SlotOption requested = SlotOption.None;
            if (SelectMorning) requested = SlotOption.SaturdayMorning;
            else if (SelectAfternoon) requested = SlotOption.SaturdayAfternoon;

            // If staying in the same slot, do nothing
            if (me.Slot == requested)
            {
                Message = "Your selection is unchanged.";
                SuccessClass = "alert-info";
                return Page();
            }

            // Capacity check: max 3 per slot
            if (requested == SlotOption.SaturdayMorning)
            {
                var count = await _db.Users.CountAsync(u => u.Slot == SlotOption.SaturdayMorning);
                if (count >= 3)
                {
                    ModelState.AddModelError(string.Empty, "This slot is unavailable. Please choose another time.");
                    return Page();
                }
            }
            else if (requested == SlotOption.SaturdayAfternoon)
            {
                var count = await _db.Users.CountAsync(u => u.Slot == SlotOption.SaturdayAfternoon);
                if (count >= 3)
                {
                    ModelState.AddModelError(string.Empty, "This slot is unavailable. Please choose another time.");
                    return Page();
                }
            }

            // Save choice (requested may be None to clear a choice)
            me.Slot = requested == SlotOption.None ? (SlotOption?)SlotOption.None : requested;
            await _db.SaveChangesAsync();

            // Reload lists for display
            await LoadListsAsync();

            // Re-check the current selection for the form
            SelectMorning = requested == SlotOption.SaturdayMorning;
            SelectAfternoon = requested == SlotOption.SaturdayAfternoon;

            Message = requested == SlotOption.None ? "You are no longer assigned to a slot." : "Your slot has been updated.";
            SuccessClass = "alert-success";
            return Page();
        }

        private async Task LoadListsAsync()
        {
            MorningMembers = await _db.Users
                .AsNoTracking()
                .Where(u => u.Slot == SlotOption.SaturdayMorning)
                .OrderBy(u => u.UserName)
                .ToListAsync();

            AfternoonMembers = await _db.Users
                .AsNoTracking()
                .Where(u => u.Slot == SlotOption.SaturdayAfternoon)
                .OrderBy(u => u.UserName)
                .ToListAsync();
        }

        private bool TryGetCurrentUserId(out int id)
        {
            id = 0;
            var value = User.FindFirstValue(ClaimTypes.NameIdentifier);
            return int.TryParse(value, out id);
        }
    }
}
