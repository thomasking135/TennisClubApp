﻿using System.Security.Claims;
using ClubApp.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Abstractions;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Routing;
using Microsoft.EntityFrameworkCore;

namespace ClubApp.Tests
{
    internal static class TestHelpers
    {
        public static AppDbContext CreateInMemoryDb(string name)
        {
            var options = new DbContextOptionsBuilder<AppDbContext>()
                .UseInMemoryDatabase(name)
                .Options;
            return new AppDbContext(options);
        }

        public static void AttachPageContext(PageModel page, int userId, string userName = "tester")
        {
            var http = new DefaultHttpContext();
            http.User = new ClaimsPrincipal(new ClaimsIdentity(new[]
            {
                new Claim(ClaimTypes.NameIdentifier, userId.ToString()),
                new Claim(ClaimTypes.Name, userName)
            }, "TestAuth"));

            var actionContext = new ActionContext(http, new RouteData(), new ActionDescriptor());
            page.PageContext = new PageContext(actionContext);
        }
    }
}
